import React from 'react';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Catalogo Abbigliamento</h1>
      <p>Benvenuto! L'interfaccia sarà qui.</p>
    </div>
  );
}

export default App;
